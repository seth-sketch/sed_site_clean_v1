<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Project — Seth Easter Design</title>
  <link rel="stylesheet" href="/assets/styles.css?v=fix16"/>
</head>
<body>
  <header class="header">
    <div class="container nav">
      <a href="/" class="brand"><img class="brand-logo" src="/assets/sed-logo-tight.svg" alt="SED"></a>
      <ul class="nav-links">
        <li><a href="/work/">Work</a></li>
        <li><a href="/press/">Press &amp; Awards</a></li>
      </ul>
    </div>
  </header>

  <main class="container">
    <section class="section work-detail">
      <div class="detail-media">
        <div id="projectHero" data-project="hero"></div>
        <div class="detail-thumbs" id="projectThumbs" data-project="thumbs"></div>
      </div>

      <aside>
        <h1 class="project-title" data-project="title">Project</h1>
        <div class="project-meta meta" data-project="meta"></div>
        <div class="detail-actions">
          <a class="btn btn-secondary project-back" data-project="back" href="/work/">← Back</a>
          <a class="btn project-next" data-project="next" href="#"><span>Next</span> →</a>
        </div>
      </aside>
    </section>
  </main>

  <footer class="footer-site">© Seth Easter.</footer>
  <script src="/js/project.js?v=fix16" defer></script>
</body>
</html>